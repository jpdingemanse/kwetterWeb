/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boundary.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import org.xml.sax.Parser;

/**
 *
 * @author 878550
 */
@ApplicationPath("api")
public class JAXRSconfig extends Application{
    
}
