import { Component } from '@angular/core';

@Component({
  selector: 'navbar-Left',
  templateUrl: './navbarLeft.html'
})
export class NavbarLeftComponent {
  title = 'app works!';
}