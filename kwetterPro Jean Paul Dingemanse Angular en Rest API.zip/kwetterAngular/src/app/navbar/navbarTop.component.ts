import { Component } from '@angular/core';

@Component({
    selector : 'navbar-Top',
    templateUrl: './navbarTop.html'
})

export class NavbarTopComponent {
    title = "Test"
}